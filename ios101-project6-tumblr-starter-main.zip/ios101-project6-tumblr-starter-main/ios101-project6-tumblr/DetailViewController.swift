//
//  DetailViewController.swift
//  ios101-project6-tumblr
//
//  Created by Ryan Hutchens on 3/30/25.
//

import UIKit
import Nuke

class DetailViewController: UIViewController {
    
    // Outlets
    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var captionTextView: UITextView!
    
    // Property to store the passed in post
    var post: Post!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Configure the UI with the data from the passed-in post
        configureUI()
    }
    
    func configureUI() {
        // Set the caption text from the post, after stripping HTML tags
        if let caption = post.caption.trimHTMLTags() {
            captionTextView.text = caption
        }
        
        // Load the post's image into the UIImageView
        if let photo = post.photos.first {
            let url = photo.originalSize.url
            Nuke.loadImage(with: url, into: postImageView)
        }
    }
}
